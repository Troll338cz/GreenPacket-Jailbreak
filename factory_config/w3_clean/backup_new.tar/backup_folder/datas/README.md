this dir is for database files.
MUST exists release version, and have read/write permission.
